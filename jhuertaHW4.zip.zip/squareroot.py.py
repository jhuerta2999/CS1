import math 

# function will allows us to provide an estimated value of root 2
def squareRoot(amount):
    acc = 0 # var will be updated after each iteration
    num = 1 
    denom = 2 
    
    # depending on the amount of terms provided it will return a value
    for i in range(amount):
        acc = num/(denom + acc)
        approximation = 1 + acc
    return approximation

def main():

    # with each iteration it will print out out its value and difference 
    for amount in range(1,21):
        print("Approximation: ", squareRoot(amount), "  Difference is: ", squareRoot(amount) - math.sqrt(2))
        
main()