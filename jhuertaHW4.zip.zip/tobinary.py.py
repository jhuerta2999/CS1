import math
# Function will determine if the number is even/odd
def isOdd(decimal):
    if decimal % 2 == 1:
        return True
    else:
        return False

# Will convert the decimal into its binary form 
def toBinary(decimal):
    binaryNum = "" # will accumulate and create and hold binary number
    if decimal == 0:
        binaryLen = 1
    else:
        binaryLen = int((math.log2(decimal) + 1) // 1) # finds number to loop based on equation 

# Depending on the number being odd/even will determine if a 1 or a 0 is added to the left of string
    for i in range(int(binaryLen)):
        if isOdd(decimal) == True:
           binaryNum = "1" + binaryNum[0:]
        else:
            binaryNum = "0" + binaryNum[0:]
        decimal = decimal // 2 # Divides number to determine next number to add to binary string
    return binaryNum

# Function will print out 32 decimal numbers with its binary number 
def main():
    
    for decimal in range(33):        
        print("Decimal form: ", decimal, "Binary form: ", toBinary(decimal))
        
main()


