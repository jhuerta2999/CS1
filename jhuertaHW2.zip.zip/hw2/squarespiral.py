import turtle # ALlow to use turtle module

spiral = turtle.Turtle()

spiral.rt(90) # Has turtle face down

"""This loop will allow us for our turtle to create a spiral starting on with a movemnet of one pixel and increasing it's distance evry time +1 to the the prior distance for 360 iterations."""
for i  in range(1, 360, 1):
    spiral.fd(i)
    spiral.rt(89)
    
turtle.exitonclick()
