def add(text):   
    equal = text.find('=')
    plus = text.find('+')
    a = text[0:plus] # it will go one spot before +
    b = text[plus+1:equal] # it will go between the + and = 
    c = text[equal+1:] # will go past =
#Depending on the location of x it will run its if statement

    if 'x' == a:
        x = int(c) - int(b)
        print(x)
    elif 'x' == b:
        x = int(c) - int(a)
        print(x)
    elif 'x' == c:
        x = int(a) + int(b)
        print(x)
   
def subtract(text):
    equal = text.find('=')
    minus = text.find('-')
    a = text[0:minus]
    b = text[minus+1:equal]
    c = text[equal+1:]

    if 'x' == a:
        x =  int(c) + int(b)
        print(x)
    elif 'x' == b:
        x = int(a) - int(c)
        print(x)
    elif 'x' == c:
        x = int(a) - int(b)
        print(x)
   
      
def main():
    eqn = input("Input equation: ")
      
    if '+' in eqn:
        (add(eqn))
    elif '-' in eqn:
        (subtract(eqn))
        
main() 

