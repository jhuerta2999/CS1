'''
A simple turtle race game
'''
# ADD import statements here
import turtle
from random import randint
'''
Initialize the window
DO NOT MODIFY
'''
def initWindow():
    window = turtle.Screen()
    window.setup(width = 610, height = 610)
    window.bgcolor("black")
    window.setworldcoordinates(0, 0, 609, 609)

    return window

'''
Draw a thick horizontal line
DO NOT MODIFY
'''
def drawLine(aTurtle, color, x, y, length):
    aTurtle.pencolor(color)
    aTurtle.up()
    aTurtle.setposition(x, y)
    aTurtle.down()
    aTurtle.forward(length)

'''
Initialize and return a single turtle
based on description in homework
'''
def initTurtle(x, y, color):
   ''' FILL IN '''
#Setting up start position of turtles
   aTurtle = turtle.Turtle()
   aTurtle.goto(x,y)
   aTurtle.shape("turtle")
   aTurtle.lt(90)
   aTurtle.color(color)
   aTurtle.up()
   return aTurtle

'''
Move a turtle based on description
in homeowrk
'''
def moveTurtle(aTurtle):
    ''' FILL IN '''
#The turtle will go through these movements once for all turtles to take turns
    for i in range(1):
        aTurtle.fd(randint(-5,12))
        aTurtle.lt(randint(-4,4))
        if aTurtle.ycor() > 430:
            return(True)
        else:
            return(False)
        
    
        
    
def main():
    window = initWindow()
        
    # Create a turtle to draw start and finish lines
    drawTurtle = turtle.Turtle()
    drawTurtle.hideturtle()
    drawTurtle.pensize(5)
    drawTurtle.speed(0)

    # Actually draw start and finish lines
    drawLine(drawTurtle, "dark goldenrod", 0, 100, 600)
    drawLine(drawTurtle, "sky blue", 0, 430, 600)

    # FILL IN HERE
# Making turtles
    red = initTurtle(270,90,"red")
    yellow = initTurtle(290,90,"yellow")
    green = initTurtle(310,90,"green")
    blue = initTurtle(330,90,"blue")

   
# Each turtle will move 100 times
    winner = False
    
    for i in range(100):
        if winner == False: 
            a = moveTurtle(red)
            if a == True:
                print("Red is winner")
                winner = True                
            b = moveTurtle(yellow)
            if b == True:
                print("Yellow is winner")
                winner = True
            c = moveTurtle(green)
            if c == True:
                print("Green us winner")
                winner = True
            d = moveTurtle(blue)
            if d == True:
                print("Blue is winner")
                winner = True
		if a and b and c and d = False:
			print("No Winner")


        
        
       
    window.exitonclick()
main()
