import math # Import math module to use trig functions

"""This function will allow us to determine the angle and the height of the 
blood droplets based upon the imputed information about the width, length, 
distance, and height of the drop"""

def main():
    widthOfDrop = float(input("Width of the bloodstain: "))
    lengthOfDrop = float(input("Length of the bloodstain: "))
    angleOfDrop = widthOfDrop / lengthOfDrop
    radianAngle = math.asin(angleOfDrop) # Obtain the radian angle
    degreeAngle = float(math.degrees(radianAngle)) # Converts from radians to degrees

    print("Angle that the droplet fell from is", degreeAngle)

    distanceFromDrop = float(input("Distance to the are of convergence: "))
    heightOfDrop = math.tan(radianAngle) * distanceFromDrop # Obtains height of the droplet

    print("Height that the droplet fell from was", heightOfDrop)
main()
